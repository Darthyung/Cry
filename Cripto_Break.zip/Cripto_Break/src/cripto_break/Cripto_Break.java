package cripto_break;

import javax.swing.JOptionPane;

public class Cripto_Break {

    public static void main(String[] args) {
        String m = JOptionPane.showInputDialog("Qual a mensagem que deseja criptografar");
        
        System.out.println((Codificacao(m)));
    }
    
    private static String Codificacao(String mensagem){
        char vet_cod [] = mensagem.toCharArray();
        char temp_d[] = new char [mensagem.length()];
        char temp_e[] = new char [mensagem.length()];
        
        String f_e = "";
        String f_d = "";
        String f = "";
        
        for (int i = 0; i < vet_cod.length;i++){
            if(i == 0 || i%2 == 0){
               f_e += vet_cod[i];
            }
            else{
               f_d += vet_cod[i];
            }
            
        }
        f = f_d + f_e;
        return f;
    }
    
    private static String Decodificacao(String mensagem){
        int tamanho = mensagem.length();
        char vet_deco[] = new char [tamanho];
        char dir[] = new char [tamanho];
        char esq[] = new char [tamanho];
        
        if (tamanho == 0 || tamanho %2 == 0){
        for (int i = 0; i < tamanho; i++){
            
        }
        }
        return null;
        
    }

}
